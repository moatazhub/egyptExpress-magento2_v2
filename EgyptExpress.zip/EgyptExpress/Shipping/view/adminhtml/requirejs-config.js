var config = {
  map: {
    '*': {
      EgyptExpressmass: 'EgyptExpress_Shipping/js/EgyptExpressmass',
      EgyptExpresscommon: 'EgyptExpress_Shipping/js/common',
      chained: 'EgyptExpress_Shipping/js/jquery.chained',
    },
  },
};
