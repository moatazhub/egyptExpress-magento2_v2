<?php

namespace EgyptExpress\Shipping\Model\Carrier\EgyptExpress\Source;

/**
 * Class to get "Defaultpaymenttype"
 */
class Defaultpaymenttype
{
    /**
     * Get array group of payment type
     *
     * @return array Array
     */
    public function toOptionArray()
    {
        $arr[] = ['value'=>'P', 'label'=>'Prepaid'];
		$arr[] = ['value'=>'C', 'label'=>'Collect'];
		$arr[] = ['value'=>'3', 'label'=>'Third Party'];
        return $arr;
    }
}
