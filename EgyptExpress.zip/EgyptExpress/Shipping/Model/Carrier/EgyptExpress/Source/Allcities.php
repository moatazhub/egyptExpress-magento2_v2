<?php

namespace EgyptExpress\Shipping\Model\Carrier\EgyptExpress\Source;

/**
 * Class to get "Allcities"
 */
class Allcities
{
    /**
     * Get array group of cities
     *
     * @return array Array
     */
    public function toOptionArray()
    {
        $arr[] = ['value'=>'RAM', 'label'=>'10th Of Ramadan'];
		$arr[] = ['value'=>'MAY', 'label'=>'15th Of May'];
		$arr[] = ['value'=>'OCT', 'label'=>'6th of October'];
        $arr[] = ['value'=>'ABS', 'label'=>'Abou Sembel'];
		$arr[] = ['value'=>'AAC', 'label'=>'Al Areesh'];
		$arr[] = ['value'=>'ALX', 'label'=>'ALEXANDRIA'];
        $arr[] = ['value'=>'SHA', 'label'=>'ALSHARKIA'];
		$arr[] = ['value'=>'ASU', 'label'=>'ASSUIT'];
		$arr[] = ['value'=>'ASW', 'label'=>'Aswan'];
        $arr[] = ['value'=>'BAD', 'label'=>'Badr City'];
		$arr[] = ['value'=>'BEH', 'label'=>'BEHARA'];
		$arr[] = ['value'=>'BNS', 'label'=>'Beni-Sueif'];
        $arr[] = ['value'=>'BRG', 'label'=>'Borg el Arab'];
		$arr[] = ['value'=>'CAI', 'label'=>'CAIRO'];
		$arr[] = ['value'=>'DHB', 'label'=>'Dahab'];
        $arr[] = ['value'=>'DAK', 'label'=>'DAKAHLIA'];
		$arr[] = ['value'=>'DAM', 'label'=>'DAMANHOUR'];
		$arr[] = ['value'=>'QDX', 'label'=>'Damietta'];
        $arr[] = ['value'=>'BAO', 'label'=>'El Bahareya Oasis'];
		$arr[] = ['value'=>'GOU', 'label'=>'El Gouna'];
		$arr[] = ['value'=>'MEN', 'label'=>'EL MONFIA'];
        $arr[] = ['value'=>'SAF', 'label'=>'El Saff'];
		$arr[] = ['value'=>'SALL', 'label'=>'El Salloum'];
		$arr[] = ['value'=>'SHZ', 'label'=>'El Sheikh Zayed'];
        $arr[] = ['value'=>'SHO', 'label'=>'El Shorouk'];
		$arr[] = ['value'=>'TOU', 'label'=>'El Tour'];
		$arr[] = ['value'=>'ELW', 'label'=>'EL WADI'];
        $arr[] = ['value'=>'FAY', 'label'=>'FAYUOM'];
		$arr[] = ['value'=>'GAR', 'label'=>'Garden City'];
		$arr[] = ['value'=>'GHA', 'label'=>'GHARBEYA'];
        $arr[] = ['value'=>'GIZ', 'label'=>'GIZA'];
		$arr[] = ['value'=>'HAA', 'label'=>'Halayeb'];
		$arr[] = ['value'=>'HEL', 'label'=>'Helopolis'];
        $arr[] = ['value'=>'HLW', 'label'=>'HELWAN'];
		$arr[] = ['value'=>'HUR', 'label'=>'Hurghada'];
		$arr[] = ['value'=>'QIV', 'label'=>'Ismailia'];
        $arr[] = ['value'=>'KAD', 'label'=>'KAFER EL DAWAR'];
		$arr[] = ['value'=>'KAZ', 'label'=>'KAFR EL SHIKH'];
		$arr[] = ['value'=>'KAL', 'label'=>'KALIUOB'];
        $arr[] = ['value'=>'QOS', 'label'=>'Kosseir'];
		$arr[] = ['value'=>'LXR', 'label'=>'Luxor'];
		$arr[] = ['value'=>'MAD', 'label'=>'Maadi'];
        $arr[] = ['value'=>'MNT', 'label'=>'Madinaty'];
		$arr[] = ['value'=>'QEK', 'label'=>'Mahalla'];
        $arr[] = ['value'=>'QSU', 'label'=>'Mansoura'];
		$arr[] = ['value'=>'MRA', 'label'=>'MARSA ALLAM'];
		$arr[] = ['value'=>'MUH', 'label'=>'Marsa Matrouh'];
        $arr[] = ['value'=>'EMY', 'label'=>'Minya'];
		$arr[] = ['value'=>'MOH', 'label'=>'MOHANDISEEN'];
		$arr[] = ['value'=>'NCO', 'label'=>'NEW CAIRO STATION'];
        $arr[] = ['value'=>'NOC', 'label'=>'North Coast'];
		$arr[] = ['value'=>'NOS', 'label'=>'North Sinai'];
		$arr[] = ['value'=>'NEW', 'label'=>'Nweiba`a'];
        $arr[] = ['value'=>'OBR', 'label'=>'OBOUR'];
        $arr[] = ['value'=>'OTH', 'label'=>'OUT STATION LOC'];
        $arr[] = ['value'=>'OMO', 'label'=>'Oyoun Moussa'];
        $arr[] = ['value'=>'PSD', 'label'=>'Port Said'];
        $arr[] = ['value'=>'QNA', 'label'=>'QUNA'];
        $arr[] = ['value'=>'RAS', 'label'=>'Rass Sedr'];
        $arr[] = ['value'=>'RES', 'label'=>'Red Sea'];
        $arr[] = ['value'=>'RHB', 'label'=>'Rehab City'];
        $arr[] = ['value'=>'RNCO', 'label'=>'Retail 5th settlement'];
        $arr[] = ['value'=>'RAIR', 'label'=>'RETAIL AIRPOR'];
        $arr[] = ['value'=>'RAMR', 'label'=>'Retail Amrea'];
        $arr[] = ['value'=>'RSMO', 'label'=>'RETAIL-SMOUHA'];
        $arr[] = ['value'=>'RABOR', 'label'=>'RETAIL.SALAH SALEM'];
        $arr[] = ['value'=>'SDT', 'label'=>'Sadat'];
        $arr[] = ['value'=>'SFG', 'label'=>'Safaga'];
        $arr[] = ['value'=>'SNK', 'label'=>'Saint Katherin'];
        $arr[] = ['value'=>'SAK', 'label'=>'Sakkara'];
        $arr[] = ['value'=>'SLO', 'label'=>'SALAH SALEM STATION'];
        $arr[] = ['value'=>'SHT', 'label'=>'Shalatin'];
        $arr[] = ['value'=>'SSH', 'label'=>'Sharm El Sheikh'];
        $arr[] = ['value'=>'SIO', 'label'=>'Siwa Oasis'];
        $arr[] = ['value'=>'QHX', 'label'=>'Sohag'];
        $arr[] = ['value'=>'SKH', 'label'=>'Sokhna'];
        $arr[] = ['value'=>'SOS', 'label'=>'South Sinai'];
        $arr[] = ['value'=>'SUZ', 'label'=>'Suez'];
        $arr[] = ['value'=>'TAB', 'label'=>'TABA'];
        $arr[] = ['value'=>'QTT', 'label'=>'Tanta'];
        $arr[] = ['value'=>'QZZ', 'label'=>'Zakazeek'];
       
        return $arr;
    }
}
