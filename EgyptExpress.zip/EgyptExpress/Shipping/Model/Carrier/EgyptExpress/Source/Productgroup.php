<?php

namespace EgyptExpress\Shipping\Model\Carrier\EgyptExpress\Source;

/**
 * Class to get "Product Group"
 */
class Productgroup
{
    /**
     * Get array group of products
     *
     * @return array Array
     */
    public function toOptionArray()
    {
        $arr[] = ['value'=>'DOM', 'label'=>'Domestic'];
        $arr[] = ['value'=>'EXP', 'label'=>'International Express'];
        return $arr;
    }
}
