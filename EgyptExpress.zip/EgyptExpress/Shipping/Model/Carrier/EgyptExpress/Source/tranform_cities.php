<?php 

$url = "http://egyptexpress.me:1929/EGEXPService.svc/CityList";

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Accept: application/json",
   "Content-Type: application/json",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = <<<DATA
{
  "UserName":"ELSFQA",
  "Password":"ZLRGVp+ZyjT6hW8Xg1PJBA=="
  
}
DATA;


curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

     $result = curl_exec($curl);
     $cities = json_decode($result, true);
     $cityList = $cities['CityListLocation'];
        foreach($cityList as $city){
          //  $i++;
            $code = $city['CityCode'];
            $name = $city['CityName'];
            
            echo "$" . "arr[] = ['value'=>'" . $code . "', 'label'=>'" .$name . "'];";
            
        }