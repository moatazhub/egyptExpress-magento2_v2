<?php

namespace EgyptExpress\Shipping\Model\Carrier;

use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Shipping\Model\Rate\Result;
//use Monolog\Logger;
//use Monolog\Handler\StreamHandler;

class EgyptExpress extends \Magento\Shipping\Model\Carrier\AbstractCarrier implements
    \Magento\Shipping\Model\Carrier\CarrierInterface
{
    /**
     * @var string
     */
    protected $_code = 'EgyptExpress';
    protected $_customLogger;
    protected $curlService;
    private $helper;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory
     * @param \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,
        \Magento\Checkout\Model\Cart $cartModel,
        \Magento\Checkout\Model\Session $checkoutSession,
        \EgyptExpress\Shipping\Helper\Data $helper,
      //  \Fkra\EgyptExpress\Logger\Logger $customLogger,
     //   \Fkra\EgyptExpress\Service\CurlService $curlService,
        array $data = []
    ) {
        $this->_rateResultFactory = $rateResultFactory;
        $this->_cart = $cartModel;
        $this->_checkoutSession = $checkoutSession;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->helper = $helper;
      //  $this->_customLogger = $customLogger;
      //  $this->curlService = $curlService;

        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }

    /**
     * @return array
     */
    public function getAllowedMethods()
    {
        //return ['EgyptExpress' => $this->getConfigData('name')];
    }


    public function proccessAdditionalValidation(\Magento\Framework\DataObject $request) {
        return true;
    }

    /**
     * @param RateRequest $request
     * @return bool|Result
     */
    public function collectRates(RateRequest $request)
    {

        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/nbe.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        // $result = $this->_rateResultFactory->create();
        // $method = $this->_rateMethodFactory->create();
        // $method->setCarrier($this->_code);
        // $method->setCarrierTitle('EgyptExpress');
        // /* Set method name */
        // $method->setMethod($this->_code);
        // $method->setMethodTitle('EgyptExpress Shipping');
        // $method->setCost(10);
        // /* Set shipping charge */
        // $method->setPrice(10);
        // $result->append($method);
        // return $result; 

        $price = 0;

        // if (!$this->getConfigFlag('active')) {
        //     return false;
        // }

        

        $data = $this->getFormData();

        $weight = $data['weight'];
        $logger->info('weight :' .$weight);
       
        
        $originCityId = $this->helper->getConfig("EgyptExpress/shipperdetail/state");//"OCT";//$this->getConfigData('origincity');
        $logger->info('originCity :' .$originCityId);

        $destinationCity = $this->_checkoutSession->getQuote()->getShippingAddress()->getRegion();
        $logger->info('destinationCity :' .$destinationCity);

        $dcityId = $this->getCityIdByName($destinationCity);
        $logger->info('dcityId111 :' .$dcityId);
       // die();

        // $response_decode = $this->curlService->postHttpRequest("http://82.129.197.86:1929/EGEXPService.svc/RateFinder",
        //     array(  "ServiceType"=>"FRG",
        //             "Product"=>"FRE",
        //             "Dimension" => "40",
        //             "Origin"=> $originCityId ,
        //             "Destination"=> $dcityId,
        //             "UserName"=>"TEST",
        //             "Password"=>"SkTAfTNEIhE=",
        //             "weight"=>$weight)
        // );

        $url = "http://82.129.197.86:1929/EGEXPService.svc/RateFinder";

                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                $headers = array(
                "Accept: application/json",
                "Content-Type: application/json",
                );
                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

                $data = <<<DATA
                {
                "UserName":"ELSFQA",
                "Password":"ZLRGVp+ZyjT6hW8Xg1PJBA==",
                "ServiceType":"FRG",
                "Product":"FRE",
                "Dimension" : "40",
                "Origin":"{$originCityId}"  ,
                "Destination": "{$dcityId}" ,
                "weight": "{$weight}"
                }
                DATA;


                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

                $result = curl_exec($curl);
                $response_decode = json_decode($result, true);

          // die("yessssssssssssssssssssssss");
        //$response_decode = json_decode($response);
        //$this->_customLogger->info('description :' .$response_decode->Description);
       // $this->_customLogger->info('code :' .$response_decode["Code"]);

        $logger->info('response_decode :' .$response_decode["Code"] );
       
        if ($response_decode["Code"] == 1)
        {
            $price = $response_decode["NetAmount"];
            // $price = $price * .25;

        }

        else
            $price = 0;

            $logger->info('NetAmount :' .$response_decode["NetAmount"] );
           

       // $this->_customLogger->info('response_code :' .$response_decode->Code);
       // $this->_customLogger->info('response_price :' .$response_decode->total_price);



        $result = $this->_rateResultFactory->create();

        $method = $this->_rateMethodFactory->create();

        $method->setCarrier('EgyptExpress');
        $method->setCarrierTitle($this->getConfigData('title'));

        $method->setMethod('EgyptExpress shipping');
        $method->setMethodTitle($this->getConfigData('name'));

        $method->setPrice($price);
        $method->setCost($price);

        $result->append($method);

        return $result;

    }

    public function getFormData()
    {
        $items = $this->_cart->getQuote()->getAllItems();

        $weight = 0;
        $qty = 0;
        foreach($items as $item) {
            $weight += ($item->getWeight() * $item->getQty()) ;
            $qty += $item->getQty();
        }

        $data['weight'] = $weight;
        $data['qty'] = $qty;

        return $data;
    }

    public function getCityIdByName($cityName){

        $url = "http://egyptexpress.me:1929/EGEXPService.svc/CityList";

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

            $headers = array(
            "Accept: application/json",
            "Content-Type: application/json",
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

            $data = <<<DATA
            {
            "UserName":"ELSFQA",
            "Password":"ZLRGVp+ZyjT6hW8Xg1PJBA=="
            
            }
            DATA;


            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

                $result = curl_exec($curl);
                $cities = json_decode($result, true);
                $cityList = $cities['CityListLocation'];
                    foreach($cityList as $city){
                        $name = $city['CityName'];
                        if($name == $cityName){

                            return $city['CityCode'];
                        }
                   
                    }

                    //echo '<pre>';print_r($citiesArray);die;
                // echo $i;
                   // print_r($citiesArray) ;


            curl_close($curl);

        // $arrContextOptions=array(
        //     "ssl"=>array(
        //         "verify_peer"=>false,
        //         "verify_peer_name"=>false,
        //     ),
        // );

        // $result = file_get_contents("https://api.egyptexpress.me/api/shippingCities", false, stream_context_create($arrContextOptions));


        // $cities = json_decode($result, true);
        // $cityList = $cities['cities'];
        // $citiesArray = array();
        // foreach($cityList as $city){

        //     $name = $city['city_en'];
        //     if($name == $cityName){
        //         return $city['id'];
        //     }
        // }
    }
    
    public function getConfigDataSystem($name){
        return $this->getConfigData($name);
    }
}
