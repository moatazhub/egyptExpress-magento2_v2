<?php

namespace EgyptExpress\Shipping\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;

/**
 * Controller for label printing
 */
class Printlabel extends \Magento\Backend\App\Action
{
    /**
     * Object of \Magento\Framework\App\Config\ScopeConfigInterface
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     *  Post request
     * @var string
     */
    private $request;

    /**
     * Object of \EgyptExpress\Shipping\Helper\Data
     * @var \EgyptExpress\Shipping\Helper\Data
     */
    private $helper;

    /**
     * Object of \Magento\Sales\Api\OrderRepositoryInterface
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var \Magento\Framework\Webapi\Soap\ClientFactory
     */
    private $soapClientFactory;
    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context                $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \EgyptExpress\Shipping\Helper\Data                       $helper
     * @param \Magento\Sales\Api\OrderRepositoryInterface        $orderRepository
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \EgyptExpress\Shipping\Helper\Data $helper,
        \Magento\Framework\Webapi\Soap\ClientFactory $soapClientFactory,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
    ) {
        $this->request = $context->getRequest();
        $this->scopeConfig = $scopeConfig;
        $this->helper = $helper;
        $this->orderRepository = $orderRepository;
        $this->soapClientFactory = $soapClientFactory;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {

        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/nbe.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        
        $_order = $this->orderRepository->get($this->request->getParam('order_id'));
          
        $clientInfo = $this->helper->getClientInfo();
        $request_body['UserName'] =  $clientInfo['AccountPin'];  
        $request_body['AccountNo'] = $clientInfo['AccountNumber'];   
        $request_body['Password'] =  $clientInfo['Password'];
        $request_body['AirwayBillNumber'] = $this->request->getParam('print_label_id');

        $url = "http://82.129.197.86:1929/EGEXPService.svc/AirwayBillPDFFormat";

        $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
            $headers = array(
            "Accept: application/json",
            "Content-Type: application/json",
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            $request_body = json_encode($request_body);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $request_body);
    
            $response = curl_exec($curl);
            $result = json_decode($response, true);

            $logger->info($result['Description']);
            //$result['Code'];
            $filepath = $result['ReportDoc']; 
        
            $pdf_b64 = base64_decode($filepath);

            header("Content-type: application/pdf");
            echo $pdf_b64;
            exit();
           
    }
   
}
