<?php

namespace EgyptExpress\Shipping\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;
use \Magento\Backend\Model\Session;

/**
 * create shipment
 */
class Shipment extends \Magento\Backend\App\Action
{
    
    /**
     * Object of \Magento\Framework\View\Result\PageFactory
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $resultPageFactory;
    /**
     * Object of \Magento\Framework\App\RequestInterface
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;
    /**
     * Object of \Magento\Framework\App\Config\ScopeConfigInterface
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;
    /**
     * Object of \Magento\Shipping\Controller\Adminhtml\Order\ShipmentLoader
     * @var \Magento\Shipping\Controller\Adminhtml\Order\ShipmentLoader
     */
    private $shipmentLoader;
    /**
     * Object of \Magento\Framework\Mail\Template\TransportBuilder
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    private $transportBuilder;
    /**
     * object of \Magento\Store\Model\StoreManagerInterface
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;
    /**
     * Object of \EgyptExpress\Shipping\Helper\Data
     * @var \EgyptExpress\Shipping\Helper\Data
     */
    private $helper;
    /**
     * Object of \Magento\Sales\Model\Order
     * @var \Magento\Sales\Model\Order
     */
    private $order;
    /**
     * object of \Magento\Framework\DB\Transaction
     * @var \Magento\Framework\DB\Transaction
     */
    private $transaction;

    /**
     * Object of \Magento\Framework\Controller\Result\JsonFactory
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;
    /**
     * @var \Magento\Framework\Webapi\Soap\ClientFactory
     */
    private $soapClientFactory;

    /**
     * @var \Magento\Sales\Model\Order\Shipment\Track
     */
    private $tracking;
    /**
     * Constructor
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
     * @param \Magento\Shipping\Controller\Adminhtml\Order\ShipmentLoader $shipmentLoader
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \EgyptExpress\Shipping\Helper\Data $helper
     * @param \Magento\Sales\Model\Order $order
     * @param \Magento\Framework\DB\Transaction $transaction
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Shipping\Controller\Adminhtml\Order\ShipmentLoader $shipmentLoader,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \EgyptExpress\Shipping\Helper\Data $helper,
        \Magento\Sales\Model\Order $order,
        \Magento\Framework\DB\Transaction $transaction,
        \Magento\Framework\Webapi\Soap\ClientFactory $soapClientFactory,
        \Magento\Sales\Model\Order\Shipment\Track $tracking
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->scopeConfig = $scopeConfig;
        $this->shipmentLoader = $shipmentLoader;
        $this->transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
        $this->request = $context->getRequest();
        $this->resultJsonFactory = $resultJsonFactory;
        $this->helper = $helper;
        $this->order = $order;
        $this->transaction = $transaction;
        $this->soapClientFactory = $soapClientFactory;
        $this->tracking = $tracking;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $post = $this->getRequest()->getPost();
        $order_id= $this->getRequest()->getParam('order_id');
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            /* here's your form processing */
            $descriptionOfGoods = "";
        $order = $this->order->load($order_id);
        foreach ($order->getAllVisibleItems() as $itemname) {
            $descriptionOfGoods .= $itemname->getId() . ' - ' . trim($itemname->getName());
        }
        $descriptionOfGoods = mb_substr($descriptionOfGoods, 0, 65, "UTF-8");
        $major_par = $this->getParams($post, $descriptionOfGoods, $order);
        $EgyptExpress_errors = $this->makeShipment($major_par, $order, $post);
        if (isset($EgyptExpress_errors['EgyptExpress_errors'])) {
            $this->_session->setData("EgyptExpress_errors", true);

            $strip = strstr($post['EgyptExpress_shipment_referer'], "EgyptExpresspopup", true);
            $url = $strip;
            if (empty($strip)) {
                $url = $post['EgyptExpress_shipment_referer'];
            }
            $resultRedirect->setUrl($url . 'EgyptExpresspopup/show');
            return $resultRedirect;
        } else {
            $this->_session->setData("EgyptExpress_errors", false);
            $resultRedirect->setUrl($post['EgyptExpress_shipment_referer']);
            return $resultRedirect;
        }
    }
    
    /**
     * Saves shipment
     *
     * @param object $shipment Shipment
     * @return void
     */
    private function _saveShipment($shipment)
    {
        $shipment->getOrder()->setIsInProcess(true);
        $this->transaction->addObject(
            $shipment
        )->addObject(
            $shipment->getOrder()
        )->save();
    }
    
    /**
     * Makes parameters collection
     *
     * @param array $post Post request
     * @param string $descriptionOfGoods Description of goods
     * @return array
     */
    private function getParams($post, $descriptionOfGoods, $order)
    {
        /////////////////////////////////////////////////////////
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/nbe.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        // prepare API post data
        $clientInfo = $this->helper->getClientInfo();

        $post['EgyptExpress_shipment_shipper_reference'];
        $logger->info("=================================================================");
        $logger->info("OrderId : ".$post['EgyptExpress_shipment_shipper_reference']);
        $logger->info("=================================================================");

        $request_body['UserName'] =  $clientInfo['AccountPin'];
        $logger->info("UserName : ".$request_body['UserName']);
        $request_body['AccountNo'] = $clientInfo['AccountNumber'];
        $logger->info("AccountNo : ".$request_body['AccountNo']);
        $request_body['Password'] =  $clientInfo['Password'];
        $logger->info("Password : ".$request_body['Password']);
        


        $request_body_sub['SendersPhone'] = $post['EgyptExpress_shipment_shipper_phone'];
        $logger->info("SendersPhone : ".$request_body_sub['SendersPhone']);
        $request_body_sub['SendersCity'] = $post['EgyptExpress_shipment_shipper_city'];
        $logger->info("SendersCity : ".$request_body_sub['SendersCity']);
        $request_body_sub['SendersAddress1'] = $post['EgyptExpress_shipment_shipper_street'];
        $logger->info("SendersAddress1 : ".$request_body_sub['SendersAddress1']);
        $request_body_sub['SendersAddress2'] = "";
        $request_body_sub['SendersContactPerson'] = $post['EgyptExpress_shipment_shipper_name'];
        $logger->info("SendersContactPerson : ".$request_body_sub['SendersContactPerson']);
        $request_body_sub['SendersCompany'] =  ($post['EgyptExpress_shipment_shipper_company'] == "") ? "shipper company" : $post['EgyptExpress_shipment_shipper_company'];
        $logger->info("SendersCompany : ".$request_body_sub['SendersCompany']);

        $request_body_sub['ReceiversCompany'] = ($post['EgyptExpress_shipment_receiver_company'] == "") ? "receiver company" : $post['EgyptExpress_shipment_receiver_company'];
        $logger->info("ReceiversCompany : ".$request_body_sub['ReceiversCompany']);
        $request_body_sub['ReceiversPhone'] = $post['EgyptExpress_shipment_receiver_phone'];
        $logger->info("ReceiversPhone : ".$request_body_sub['ReceiversPhone']);
        $request_body_sub['ReceiversCity'] = $post['EgyptExpress_shipment_receiver_city'];
        $logger->info("ReceiversCity : ".$request_body_sub['ReceiversCity']);
        $request_body_sub['ReceiversAddress1'] = $post['EgyptExpress_shipment_receiver_street'];
        $logger->info("ReceiversAddress1 : ".$request_body_sub['ReceiversAddress1']);
        $request_body_sub['ReceiversAddress2'] = "";

        $cod_amount = ($post['EgyptExpress_shipment_info_custom_amount'] == '') ? 0 : $post['EgyptExpress_shipment_info_custom_amount'];
        $request_body_sub['CODAmount'] = $cod_amount;
        $logger->info("CODAmount : ".$request_body_sub['CODAmount']);

        $totalItems = (trim($post['number_pieces']) == '') ? 1 : (int) $post['number_pieces'];
        $request_body_sub['NumberofPeices'] = $totalItems;
        $logger->info("NumberofPeices : ".$request_body_sub['NumberofPeices']);

        $totalWeight = ($post['order_weight'] == '') ? 0.5 : $post['order_weight'];
        $request_body_sub['Weight'] = $totalWeight;
        $logger->info("Weight : ".$request_body_sub['Weight']);

        $request_body_sub['ShipmentDimension'] = "1";
        $logger->info("ShipmentDimension : ".$request_body_sub['ShipmentDimension']);

        $descriptionOfGoods = "";
        $good_desc = (trim($post['EgyptExpress_shipment_description']) == '') ? $descriptionOfGoods :
                     $post['EgyptExpress_shipment_description'];
        $request_body_sub['GoodsDescription'] = $good_desc;
        $logger->info("GoodsDescription : ".$request_body_sub['GoodsDescription']);

        $request_body_sub['Origin'] = $post['EgyptExpress_shipment_shipper_state'];
        $logger->info("Origin : ".$request_body_sub['Origin']);
        $request_body_sub['order_id'] = $post['EgyptExpress_shipment_shipper_reference'];
        $logger->info("order_id : ".$request_body_sub['order_id']);
        $request_body_sub['ServiceType'] = "FRG";
        $logger->info("ServiceType : ".$request_body_sub['ServiceType']);
        $request_body_sub['ProductType'] = "FRE"; 
        $logger->info("ProductType : ".$request_body_sub['ProductType']);
        $request_body_sub['Destination'] = $post['EgyptExpress_shipment_receiver_state'];
        $logger->info("Destination : ".$request_body_sub['Destination']);
       
        $request_body['AirwayBillData'] = $request_body_sub;
       // $this->messageManager->addError('EgyptExpress: ' . $request_body);
        return $request_body;

    }
    
   
    
    /**
     * Makes shipment functionality
     *
     * @param array $major_par Parameters
     * @param object $order Order
     * @param array $post Post request
     * @return array Feedback from EgyptExpress server
     */
    private function makeShipment($major_par, $order, $post)
    {

       
        $url = "http://82.129.197.86:1929/EGEXPService.svc/CreateAirwayBill";
        try {
            //create shipment call
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
            $headers = array(
            "Accept: application/json",
            "Content-Type: application/json",
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            $request_body = json_encode($major_par);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $request_body);
    
            $response = curl_exec($curl);
           
            // if (curl_error($curl)) {
            //     $this->messageManager->addError('EgyptExpress: ' . curl_error($curl));
            //     //$this->processError(curl_error($curl));
            //     //curl_close($curl);
            //     return ['EgyptExpress_errors' => true];
            
            //  //curl_close($curl);

            //    // $auth_call = $soapClient->CreateShipments($major_par);
            // // if ($auth_call->HasErrors) {
            // //     $this->processError($auth_call);
            // //      return ['EgyptExpress_errors' => true];
            // }
            $result = json_decode($response, true);
           // if(isset($result->Code)) {
            if($result['Code'] != 1){
                $this->messageManager->addError('EgyptExpress: ' . $result['Description']);
                return ['EgyptExpress_errors' => true];
            }
          //  }
            
            else {
                
                $data = [
                        'items' => $post['EgyptExpress_items'],
                        'comment_text' => "EgyptExpress Shipment Order AWB No. " . $result["AirwayBillNumber"] . " - Order No. " . $order->getId() .
                        " <a style='color:red;'>Print Label #"  . $result['AirwayBillNumber'] ."</a>",
                        'comment_customer_notify' => true,
                        'is_visible_on_front' => true
                    ];
                if ($order->canShip() && $post['EgyptExpress_return_shipment_creation_date'] == "create") {
                    $this->shipmentLoader->setOrderId($order->getId());
                    $this->shipmentLoader->setShipmentId(null);
                    $this->shipmentLoader->setShipment($data);
                    $this->shipmentLoader->setTracking(null);
                    $shipment = $this->shipmentLoader->load();

                    if ($shipment) {
                        $track = $this->tracking->setNumber(
                            $result['AirwayBillNumber']
                        )->setCarrierCode(
                            "EgyptExpress"
                        )->setTitle(
                            "EgyptExpress Shipping"
                        );
                        $shipment->addTrack($track);
                    }
                    if (!$shipment) {
                        $this->_forward('noroute');
                        return;
                    }
                    if (!empty($data['comment_text'])) {
                        $shipment->addComment(
                            $data['comment_text'],
                            isset($data['comment_customer_notify']),
                            isset($data['is_visible_on_front'])
                        );

                        $shipment->setCustomerNote($data['comment_text']);
                        $shipment->setCustomerNoteNotify(isset($data['comment_customer_notify']));
                    }

                    ///////////// block shipment
                    $shipment->register();
                    $this->_saveShipment($shipment);
                   // $this->sendEmail($post, $order, $auth_call);
                    $this->messageManager->addSuccess(
                        'EgyptExpress Shipment Number: ' . $result['AirwayBillNumber'] .
                                ' has been created.'
                    );
                // } elseif ($post['EgyptExpress_return_shipment_creation_date'] == "return") {
                //     $this->sendEmail($post, $order, $auth_call);
                //     $baseUrl = $this->storeManager->getStore()->getBaseUrl();
                //     $message = "EgyptExpress Shipment Return Order AWB No. " . $auth_call->Shipments->ProcessedShipment->
                //             ID . " - Order No. " . $order->getId() .
                //             " <a style='color:red;'>Print Label #"  . $auth_call->Shipments->ProcessedShipment->ID .
                //             "</a>";
                //     $this->messageManager->addSuccess('EgyptExpress Shipment Return Order Number: ' . $auth_call->
                //             Shipments->ProcessedShipment->ID . ' has been created.');
                //     $order->addStatusToHistory($order->getStatus(), $message, false);
                //     $order->save();
                 } else {
                    $this->messageManager->addError('Cannot do shipment for the order.');
                }
            }
        } catch (\Exception $e) {
            $this->messageManager->addError('adminhtml/session')->addError($e->getMessage());
            return ['EgyptExpress_errors' => true];
        }
    }
    /**
     * Creates error messages
     *
     * @param array $auth_call  Feedback from EgyptExpress server
     * @return void
     */
    private function processError($auth_call)
    {
        if (empty($auth_call->Shipments)) {
            if (!is_object($auth_call->Notifications->Notification)) {
                foreach ($auth_call->Notifications->Notification as $notify_error) {
                    $this->messageManager->addError('EgyptExpress: ' . $notify_error->Code . ' - ' .
                            $notify_error->Message);
                }
            } else {
                $this->messageManager->addError('EgyptExpress: ' . $auth_call->Notifications->Notification->Code
                   . ' - ' . $auth_call->Notifications->Notification->Message);
            }
        } elseif (isset($auth_call->Notifications->Notification)) {
            $this->messageManager->addError('EgyptExpress: ' . $auth_call->Notifications->Notification->Code
            . ' - ' . $auth_call->Notifications->Notification->Message);
        } else {
            if (!is_object($auth_call->Shipments->ProcessedShipment->Notifications->Notification)) {
                $notification_string = '';
                foreach ($auth_call->Shipments->ProcessedShipment->Notifications->Notification as $notification_error) {
                            $notification_string .= $notification_error->Code . ' - '
                                    . $notification_error->Message . ' <br />';
                }
                $this->messageManager->addError($notification_string);
            } else {
                $this->messageManager->addError('EgyptExpress: ' . $auth_call->Shipments->ProcessedShipment->
                        Notifications->Notification->Code . ' - ' . $auth_call->Shipments->ProcessedShipment->
                        Notifications->Notification->Message);
            }
        }
    }
}
