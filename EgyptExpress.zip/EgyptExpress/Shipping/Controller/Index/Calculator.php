<?php

namespace EgyptExpress\Shipping\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

    /**
     * Controller for "Rate calculator" functionality
     */
class Calculator extends Action
{
    /**
     * Object of \Magento\Framework\App\RequestInterface
     *
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;
    
     /**
      * Object of \Magento\Framework\Data\Form\FormKey
      * @var \Magento\Framework\Data\Form\FormKey
      */
    private $formKey;

     /**
      * Object of \Magento\Framework\Controller\Result\JsonFactory
      * @var \Magento\Framework\Controller\Result\JsonFactory
      */
    private $resultJsonFactory;
    
     /**
      * Object of \EgyptExpress\Shipping\Model\EgyptExpresscalculator
      * @var \EgyptExpress\Shipping\Model\EgyptExpresscalculator
      */
    private $EgyptExpresscalculator;
    /**
     * {@inheritdoc}
     * @param  Context $context
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \EgyptExpress\Shipping\Model\EgyptExpresscalculator $EgyptExpresscalculator
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \EgyptExpress\Shipping\Model\EgyptExpresscalculator $EgyptExpresscalculator,
        \Magento\Framework\Data\Form\FormKey $formKey
    ) {
        parent::__construct($context);
        $this->request = $context->getRequest();
        $this->resultJsonFactory = $resultJsonFactory;
        $this->EgyptExpresscalculator = $EgyptExpresscalculator;
        $this->formKey = $formKey;
    }
    /**
     * {@inheritdoc}
     */
    public function execute()
    {

        if ($this->request->getParam('form_key') === null || $this->request->getParam('form_key') !=
            $this->formKey->getFormKey()) {
            return  $this->resultJsonFactory->create()->setData($this->__('Invalid form data.'));
        }
        $address = [];
        $address['destination_city'] = $this->request->getParam('city');
        $address['destination_post_code'] = $this->request->getParam('post_code');
        $address['destination_country_code'] = $this->request->getParam('country_code');
        $address['currency'] = $this->request->getParam('currency');
        $address['storeId'] = $this->request->getParam('store_id');
        $address['product_id'] = $this->request->getParam('product_id');
        $response = $this->EgyptExpresscalculator->getRate($address);
        return  $this->resultJsonFactory->create()->setData($response);
    }
}
